# Github repository

link : https://github.com/1702KAI/Unison-App/tree/dev-backend

The Repo contains  

1. unisonapp
2. unisonapp-backend

## unisonapp

This contains the front end built using flutter, it includes the authentication page, registration pages and home page with navigation bar

## unisonapp-backend

This contains a laravel project.

- [ ]  Created the necessary database schemas
- [ ]  Database migrations have been done in database/migrations/2023_09_08_061943_create_user_details_table.php
- [ ]  app/Actions/Fortify/CreateNewUser.php have been configured to register a new user to the app
- [ ]  app/Http/Controllers/UsersController.php have been configured to login into the app
- [ ]  necessary routes have been configured in routes/api.php

Successful token retrieval from database for registered user

try with the following credentials

> email : [qabybogepu@mailinator.com](mailto:qabybogepu@mailinator.com)
> password : hundfkjh5

or register as new user, download the github repo and open the unisonapp-backend in vs code and run `php artisan serve` , you should be able to register as a new user through the admin dashboard, this is yet to be implemented in the front end.
