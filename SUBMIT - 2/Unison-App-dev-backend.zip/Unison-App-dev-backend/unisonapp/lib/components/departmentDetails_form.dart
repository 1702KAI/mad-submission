import 'package:flutter/material.dart';
import '../utils/config.dart';

class DepartmentDetailsForm extends StatefulWidget {
  const DepartmentDetailsForm({Key? key}) : super(key: key);

  @override
  State<DepartmentDetailsForm> createState() => _DepartmentDetailsFormState();
}

class _DepartmentDetailsFormState extends State<DepartmentDetailsForm> {
  String? _selectedDepartment; // Store the selected department as a String

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Form(
        key: GlobalKey<FormState>(), // Use GlobalKey<FormState> for the form key
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              Config.spaceSmall,
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 15),
                alignment: Alignment.centerLeft,
                child: const Text(
                  'Select your department',
                  style: TextStyle(
                    fontFamily: 'helveticaFont',
                    color: Config.secondaryColor,
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              Config.spaceSmall,
              DropdownButtonFormField<String>(
                value: _selectedDepartment,
                decoration: const InputDecoration(
                  labelText: 'Select your department',
                  labelStyle: TextStyle(color: Colors.black38),
                  alignLabelWithHint: true,
                  prefixIcon: Icon(Icons.business), // You can change the icon
                  prefixIconColor: Config.secondaryColor,
                ),
                items: [
                  'Finance',
                  'HR',
                  'Marketing',
                  'Operation',
                  'Sales',
                  'Development',
                ].map<DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
                onChanged: (String? newValue) {
                  setState(() {
                    _selectedDepartment = newValue;
                  });
                },
              ),
              Config.spaceSmall,
              TextFormField(
                keyboardType: TextInputType.visiblePassword,
                cursorColor: Config.secondaryColor,
                style: const TextStyle(color: Colors.black),
                decoration: const InputDecoration(
                  hintText: 'Enter your role',
                  labelText: 'Enter your role',
                  labelStyle: TextStyle(color: Colors.black38),
                  alignLabelWithHint: true,
                  prefixIcon: Icon(Icons.lock_outline),
                  prefixIconColor: Config.secondaryColor,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
