import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:unisonapp/screens/home_page.dart';
import 'package:unisonapp/utils/config.dart';

class MainLayout extends StatefulWidget {
  const MainLayout({Key? key}) : super(key: key);

  @override
  State<MainLayout> createState() => _MainLayoutState();
}

class _MainLayoutState extends State<MainLayout> {
  // Variable declaration
  int currentPage = 0;
  final PageController _page = PageController();

  // Function to handle the logo click
  void _handleLogoClick() {
    // Implement your logo click logic here
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CustomScrollView(
        slivers: [
          // Define the app bar
          SliverAppBar(
            title: const Text('Home', style: TextStyle(color: Colors.black)),
            actions: <Widget>[
              GestureDetector(
                onTap: _handleLogoClick, // Handle the logo click
                child: SizedBox(
                  child: Image.asset(
                    'assets/logos/icon logo (1).png',
                    width: 80,
                  ),
                ),
              ),
            ],
            backgroundColor: Config.paintColor,
            elevation: 0, // Set the app bar color to white
          ),
          // Define the page content
          SliverFillRemaining(
            child: PageView(
              controller: _page,
              onPageChanged: (index) {
                setState(() {
                  currentPage = index;
                });
              },
              children: const <Widget>[
                HomePage(),
              ],
            ),
          ),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            const DrawerHeader(
              decoration: BoxDecoration(
                color: Config.paintColor,
              ),
              child: Text(
                'Drawer Header',
                style: TextStyle(
                  color: Config.secondaryColor,
                  fontSize: 24,
                ),
              ),
            ),
            ListTile(
              title: const Text('Item 1'),
              onTap: () {
                Navigator.pop(context);
              },
            ),
            ListTile(
              title: const Text('Item 2'),
              onTap: () {
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
      bottomNavigationBar: Container(
        color: Config.primaryColor, // Set the background color of the BottomNavigationBar
        child: BottomNavigationBar(
          currentIndex: currentPage,
          selectedItemColor: Color.fromARGB(255, 0, 0, 0), // Set your desired selected item color here
          unselectedItemColor: const Color.fromARGB(255, 0, 0, 0), // Set your desired unselected item color here
          onTap: (page) {
            setState(() {
              currentPage = page;
              _page.animateToPage(
                page,
                duration: const Duration(milliseconds: 500),
                curve: Curves.easeInOut,
              );
            });
          },
          items: const <BottomNavigationBarItem>[
            BottomNavigationBarItem(
              icon: FaIcon(FontAwesomeIcons.house),
              label: 'Home',
              backgroundColor: Config.primaryColor,
            ),
            BottomNavigationBarItem(
              icon: FaIcon(FontAwesomeIcons.solidCalendarCheck),
              label: 'Appointments',
              backgroundColor: Config.primaryColor,
            ),
            BottomNavigationBarItem(
              icon: FaIcon(FontAwesomeIcons.plus),
              label: 'Create',
              backgroundColor: Config.primaryColor,
            ),
            BottomNavigationBarItem(
              icon: FaIcon(FontAwesomeIcons.message),
              label: 'Chat',
              backgroundColor: Config.primaryColor,
            ),
            BottomNavigationBarItem(
              icon: FaIcon(FontAwesomeIcons.bars),
              label: 'Menu',
              backgroundColor: Config.primaryColor,
            ),
          ],
        ),
      ),
    );
  }
}
