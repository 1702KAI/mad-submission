import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:unisonapp/components/bankingDetails_form.dart';
import 'package:unisonapp/components/addressDetails_form.dart';
import 'package:unisonapp/components/personalDetails_form.dart';
import 'package:unisonapp/utils/config.dart';
import 'data_classes/personalDetails_data.dart';

class RegistrationLayout extends StatefulWidget {
  const RegistrationLayout({Key? key}) : super(key: key);

  @override
  State<RegistrationLayout> createState() => _RegistrationLayoutState();
}

class _RegistrationLayoutState extends State<RegistrationLayout>
    with SingleTickerProviderStateMixin {
  int currentPage = 0;
  late TabController _tabController;
  late PersonalDetailsData personalDetailsData;


  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    personalDetailsData = Provider.of<PersonalDetailDataProvider>(context).personalDetailsData;
  }

  // Define the changeTabIndex function here
  void changeTabIndex(int index) {
    setState(() {
      currentPage = index;
      _tabController.animateTo(currentPage);
    });
  }

  @override
  Widget build(BuildContext context) {
    Config().init(context);
    final List<GlobalKey<FormState>> formKeys = [
      GlobalKey<FormState>(),
      GlobalKey<FormState>(),
      GlobalKey<FormState>(),
    ];
    final List<bool> formValidations = [false, false, false];

    return Scaffold(
      resizeToAvoidBottomInset: true,
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.max,
          children: <Widget>[
            Config.spaceHuge,
            Center(
              child: Column(
                children: [
                  Image.asset(
                    'assets/logos/Metana Logo - Black.png',
                    width: 250,
                  ),
                ],
              ),
            ),
            Config.spaceSmall,
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 15),
              alignment: Alignment.centerLeft,
              child: const Text(
                'Request an account',
                style: TextStyle(
                  fontFamily: 'helveticaFont',
                  color: Config.secondaryColor,
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            Config.spaceSmall,
            TabBar(
              controller: _tabController,
              labelColor: Config.secondaryColor,
              onTap: (index) {
                // create a switch statement to handle the different cases
                if (index > 0 && !formValidations[index - 1]) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Please fill out the previous form first.'),
                    ),
                  );
                } else {
                  _tabController.animateTo(index);
                }
              },
              tabs: const [
                Tab(
                  text: 'Personal Details',
                ),
                Tab(
                  text: 'Address Details',
                ),
                Tab(
                  text: 'Banking Details',
                ),
              ],
            ),
            Expanded(
              child: TabBarView(
                controller: _tabController,
                physics: NeverScrollableScrollPhysics(),
                children: [
                  PersonalDetailsForm(
                    formKey: formKeys[0],
                    onValidationChanged: (isValid) {
                      setState(() {
                        formValidations[0] = isValid;
                      });
                    },
                    changeTabIndex: changeTabIndex,
                    personalDetailsData: PersonalDetailsData(
                      firstName: personalDetailsData.firstName,
                      lastName: personalDetailsData.lastName,
                      email: personalDetailsData.email,
                      country: personalDetailsData.country,
                      birthday: personalDetailsData.birthday,
                      mobileNumber: personalDetailsData.mobileNumber,
                    )

                  ),
                  AddressDetailsForm(
                    // formKey: formKeys[1],
                    // onValidationChanged: (isValid) {
                    //   setState(() {
                    //     formValidations[1] = isValid;
                    //   });
                    // },
                  ),
                  BankingDetailsForm(
                    // formKey: formKeys[2],
                    // onValidationChanged: (isValid) {
                    //   setState(() {
                    //     formValidations[2] = isValid;
                    //   });
                    // },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
