class Notifications {
  final String title;
  final String sentTime;
  final String from;

  Notifications({
    required this.title,
    required this.sentTime,
    required this.from,
  });
}